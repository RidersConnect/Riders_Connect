﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string con = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\computers\\Documents\\Database1.mdf;Integrated Security=True;Connect Timeout=30";
        
        string lname_get,
        fname_get,
        username_get,
        password_get,
        email_get,
        phn_get,
        m_get,
        d_get,
        y_get,
        g_get,
        bike_get;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       

        protected void Button1_Click(object sender, EventArgs e)
        {
          
            string qry = @"SELECT fname, lname, username, password, email, month, day, year, gender, favouritebike FROM signup1 WHERE username = @usrnm";
            SqlConnection sqlcon = new SqlConnection(con);
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand(qry,sqlcon);
            cmd.Parameters.Add("@usrnm", SqlDbType.VarChar).Value = TextBox1.Text.ToString();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    lname_get = (string)reader[1];
                    fname_get = (string)reader[0];
                    username_get = (string)reader[2];
                    //Label2.Text = username_get;
                    password_get = (string)reader[3];
                    //Label3.Text = password_get;
                    email_get = (string)reader[4];
                   
                    m_get = (string)reader[5];
                    d_get = (string)reader[6];
                    y_get = (string)reader[7];
                    g_get = (string)reader[8];
                    bike_get = (string)reader[9];
                }
            }
            if (password_get == TextBox2.Text.ToString() && username_get == TextBox1.Text.ToString())
            {
                
                Session["lname_sent"] = lname_get;
                Session["fname_set"] = fname_get;
                Session["email_set"] = email_get;
                Session["m_set"] = m_get;
                Session["d_set"] = d_get;
                Session["y_set"] = y_get;
                Session["g_set"] = g_get;
                Session["bike_set"] = bike_get;

                Response.Redirect("profile page.aspx");
            }
            else
            {
                Label1.Text = "Incorrect Email or Password";
            }
            
        }
    }
}




