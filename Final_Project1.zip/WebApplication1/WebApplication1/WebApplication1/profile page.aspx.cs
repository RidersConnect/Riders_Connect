﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class profile_page : System.Web.UI.Page
    {
        string con = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\computers\\Documents\\Database1.mdf;Integrated Security=True;Connect Timeout=30";
        string lname_get,
        fname_get,
        email_get,
        phn_get,
        m_get,
        d_get,
        y_get,
        g_get,
        bike_get;

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm1.aspx");
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string fn = Session["fname_set"].ToString();
            string ln = Session["lname_sent"].ToString();
            string em = Session["email_set"].ToString();
            string m = Session["m_set"].ToString();
            string d = Session["d_set"].ToString();
            string y = Session["y_set"].ToString();
            string g = Session["g_set"].ToString();
            string bike = Session["bike_set"].ToString();
            TextBox1.Text = fn;
            TextBox2.Text = ln;
            TextBox4.Text = em;
            TextBox7.Text = m+"-"+d+"-"+y;
            
            TextBox8.Text = g;
            TextBox3.Text = bike;
            Label8.Text = "Hello "+fn+" !";


        }

        
        protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string qry = @"SELECT fname, lname, email, month, day, year, gender, favouritebike FROM signup1 WHERE username = @usrnm";
            SqlConnection sqlcon = new SqlConnection(con);
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand(qry, sqlcon);
            cmd.Parameters.Add("@usrnm", SqlDbType.VarChar).Value = TextBox9.Text.ToString();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                
                    if (reader.Read())
                    {
                        lname_get = (string)reader[1];
                    Label1.Text = "";
                        fname_get = (string)reader[0];
                    Label2.Text = "Name: "+fname_get+" "+lname_get;
                        //username_get = (string)reader[2];
                        //Label2.Text = username_get;
                        //password_get = (string)reader[3];
                        //Label3.Text = password_get;
                        email_get = (string)reader[2];
                    Label3.Text = "Email: "+email_get;
                        
                        m_get = (string)reader[3];
                        d_get = (string)reader[4];
                        y_get = (string)reader[5];
                    Label5.Text = "Date of Birth: " + m_get + "-" + d_get + "-" + y_get;
                        g_get = (string)reader[6];
                    Label6.Text = "Gender: " + g_get.ToString();
                        bike_get = (string)reader[7];
                    Label7.Text = "Favourite Bike: " + bike_get;
                    Label1.Visible = true;
                    Label2.Visible = true;
                    Label3.Visible = true;
                    Label6.Visible = true;
                    Label7.Visible = true;
                }
                else
                {
                    Label1.Visible = false;
                    Label2.Visible = false;
                    Label3.Visible = false;
                    Label6.Visible = false;
                    Label7.Visible = false;
                    Label5.Text = "Search not found";
                }
                
                
            }
           
        }
    }
}