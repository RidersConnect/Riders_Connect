﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class signup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string cnsstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\computers\\Documents\\Database1.mdf;Integrated Security=True;Connect Timeout=30";
        
        


        public object Rows { get; internal set; }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cnsstring);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string a = "insert into signup1(fname,lname,username,password,email,month,day,year,gender,favouritebike) values(' " + TextBox2.Text.ToString() + " ' , ' " + TextBox3.Text.ToString() + " ' , '"+TextBox4.Text.ToString()+"', '"+TextBox5.Text.ToString()+"', ' " + TextBox6.Text.ToString() + " ' , ' " + DropDownList1.Text.ToString() + " ' , ' " + DropDownList2.Text.ToString() + " ' , ' " + DropDownList3.Text.ToString() + " ' , ' " + DropDownList5.Text.ToString() + " ' , ' " + DropDownList6.Text.ToString() + " ') ";
                SqlCommand cmd = new SqlCommand(a, con);
                cmd.ExecuteNonQuery();
                Label1.Text = "sign up Successfully";
                

            }
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}